
import './App.css';
import MisRutas from './routes/MisRutas';

function App() {
  return (
    <div>
      <MisRutas/>
    </div>
  );
}

export default App;
