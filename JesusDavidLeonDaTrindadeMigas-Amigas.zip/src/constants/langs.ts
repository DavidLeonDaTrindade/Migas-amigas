export const LANGUAGES = [
    {label: "Spanish", code:"es"},
    {label: "Portuguese", code:"pt"},
];